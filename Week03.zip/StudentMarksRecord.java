import java.util.ArrayList;
import java.util.Scanner;

public class StudentMarksRecord {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        ArrayList<Integer> marks = new ArrayList<>();

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();

        for (int i = 0; i < n; i++) {

            System.out.print("Enter marks of student " + (i + 1) + ": ");
            int mark = sc.nextInt();

            marks.add(mark);
        }

        int highest = marks.get(0);
        int lowest = marks.get(0);

        for (int mark : marks) {

            if (mark > highest) {
                highest = mark;
            }

            if (mark < lowest) {
                lowest = mark;
            }
        }

        System.out.println("\n----- Student Marks Record -----");

        for (int i = 0; i < marks.size(); i++) {
            System.out.println("Student " + (i + 1) + ": " + marks.get(i));
        }

        System.out.println("\nHighest Marks: " + highest);
        System.out.println("Lowest Marks: " + lowest);

        sc.close();
    }
}