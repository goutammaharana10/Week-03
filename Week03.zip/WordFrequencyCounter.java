import java.io.*;
import java.util.*;

public class WordFrequencyCounter {

    public static void main(String[] args) {

        HashMap<String, Integer> words = new HashMap<>();

        try {

            // Reading input file
            FileReader fr = new FileReader("input.txt");
            BufferedReader br = new BufferedReader(fr);

            String line;

            while ((line = br.readLine()) != null) {

                String[] wordList = line.toLowerCase().split("\\W+");

                for (String word : wordList) {

                    if (!word.isEmpty()) {

                        words.put(word, words.getOrDefault(word, 0) + 1);
                    }
                }
            }

            br.close();

            // Sorting words alphabetically
            TreeMap<String, Integer> sortedWords = new TreeMap<>(words);

            // Writing output file
            FileWriter fw = new FileWriter("output.txt");

            for (String word : sortedWords.keySet()) {

                fw.write(word + " : " + sortedWords.get(word) + "\n");
            }

            fw.close();

            System.out.println("Word frequency counted successfully!");

            System.out.println("\nWord Frequency:");

            for (String word : sortedWords.keySet()) {

                System.out.println(word + " : " + sortedWords.get(word));
            }

        } catch (FileNotFoundException e) {

            System.out.println("Input file not found!");

        } catch (IOException e) {

            System.out.println("An error occurred while handling the file.");
        }
    }
}