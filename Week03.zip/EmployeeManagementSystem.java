import java.util.*;
import java.io.*;

class Employee {

    int id;
    String name;
    String department;
    double salary;

    Employee(int id, String name, String department, double salary) {

        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    void display() {

        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Department: " + department);
        System.out.println("Salary: " + salary);

        System.out.println("-------------------------");
    }
}

public class EmployeeManagementSystem {

    static ArrayList<Employee> employees = new ArrayList<>();

    static Scanner sc = new Scanner(System.in);

    static String fileName = "employees.txt";

    // Add Employee
    static void addEmployee() {

        try {

            System.out.print("Enter Employee ID: ");
            int id = Integer.parseInt(sc.nextLine());

            if (findEmployee(id) != null) {
                System.out.println("Employee ID already exists!");
                return;
            }

            System.out.print("Enter Employee Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Department: ");
            String department = sc.nextLine();

            System.out.print("Enter Salary: ");
            double salary = Double.parseDouble(sc.nextLine());

            if (id <= 0 || salary < 0 ||
                name.trim().isEmpty() || department.trim().isEmpty() ||
                name.contains("|") || department.contains("|")) {

                System.out.println("Invalid employee details!");
                return;
            }

            Employee emp = new Employee(id, name, department, salary);

            employees.add(emp);

            saveEmployees();

            System.out.println("Employee added successfully!");

        } catch (NumberFormatException e) {

            System.out.println("Invalid input! Enter correct numbers.");

        }
    }

    // Display Employees
    static void displayEmployees() {

        if (employees.isEmpty()) {

            System.out.println("No employee records found.");
            return;
        }

        System.out.println("\n----- Employee Records -----");

        for (Employee emp : employees) {

            emp.display();
        }
    }

    // Search Employee
    static Employee findEmployee(int id) {

        for (Employee emp : employees) {

            if (emp.id == id) {

                return emp;
            }
        }

        return null;
    }

    static void searchEmployee() {

        try {

            System.out.print("Enter Employee ID: ");
            int id = Integer.parseInt(sc.nextLine());

            Employee emp = findEmployee(id);

            if (emp != null) {

                System.out.println("\nEmployee Found:");
                emp.display();

            } else {

                System.out.println("Employee not found!");
            }

        } catch (NumberFormatException e) {

            System.out.println("Invalid ID!");
        }
    }

    // Delete Employee
    static void deleteEmployee() {

        try {

            System.out.print("Enter Employee ID to delete: ");
            int id = Integer.parseInt(sc.nextLine());

            Employee emp = findEmployee(id);

            if (emp != null) {

                employees.remove(emp);

                saveEmployees();

                System.out.println("Employee deleted successfully!");

            } else {

                System.out.println("Employee not found!");
            }

        } catch (NumberFormatException e) {

            System.out.println("Invalid ID!");
        }
    }

    // Save Employees to File
    static void saveEmployees() {

        try {

            FileWriter fw = new FileWriter(fileName);

            for (Employee emp : employees) {

                fw.write(
                    emp.id + "|" +
                    emp.name + "|" +
                    emp.department + "|" +
                    emp.salary + "\n"
                );
            }

            fw.close();

        } catch (IOException e) {

            System.out.println("Error saving employee records!");
        }
    }

    // Load Employees from File
    static void loadEmployees() {

        try {

            File file = new File(fileName);

            if (!file.exists()) {
                return;
            }

            BufferedReader br = new BufferedReader(
                new FileReader(file)
            );

            String line;

            while ((line = br.readLine()) != null) {

                try {

                    String[] data = line.split("\\|", -1);

                    if (data.length != 4) {
                        continue;
                    }

                    int id = Integer.parseInt(data[0]);

                    String name = data[1];

                    String department = data[2];

                    double salary = Double.parseDouble(data[3]);

                    if (id > 0 && salary >= 0 &&
                        !name.trim().isEmpty() &&
                        !department.trim().isEmpty() &&
                        findEmployee(id) == null) {

                        employees.add(
                            new Employee(id, name, department, salary)
                        );
                    }

                } catch (NumberFormatException e) {

                    System.out.println("Skipping invalid employee record.");
                }
            }

            br.close();

        } catch (IOException e) {

            System.out.println("Error loading employee records!");
        }
    }

    // Main Method
    public static void main(String[] args) {

        loadEmployees();

        int choice = 0;

        do {

            System.out.println("\n================================");
            System.out.println("   EMPLOYEE MANAGEMENT SYSTEM");
            System.out.println("================================");

            System.out.println("1. Add Employee");
            System.out.println("2. Display Employees");
            System.out.println("3. Search Employee");
            System.out.println("4. Delete Employee");
            System.out.println("5. Save Employees");
            System.out.println("6. Exit");

            System.out.print("\nEnter your choice: ");

            try {

                choice = Integer.parseInt(sc.nextLine());

            } catch (NumberFormatException e) {

                System.out.println("Please enter a valid number!");
                continue;
            }

            switch (choice) {

                case 1:
                    addEmployee();
                    break;

                case 2:
                    displayEmployees();
                    break;

                case 3:
                    searchEmployee();
                    break;

                case 4:
                    deleteEmployee();
                    break;

                case 5:
                    saveEmployees();
                    System.out.println("Records saved successfully!");
                    break;

                case 6:
                    saveEmployees();
                    System.out.println("Thank you for using the system!");
                    break;

                default:
                    System.out.println("Invalid choice!");
            }

        } while (choice != 6);

        sc.close();
    }
}